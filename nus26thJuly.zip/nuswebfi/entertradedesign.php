
<?php
include 'dbconn.php';

$country = "SELECT * FROM clientcompanydata";
$county_qry = mysqli_query($conn, $country);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.jquery.min.js"></script>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous"> -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/entertrade.css">
    <!-- <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/functions.js"></script> -->
    <title>NUS Consulting Group | Entertrade</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    
</head>
<body>

    <div class="containertrade">
        <form action="">
            <div class="header">
                <h2 class="entry">Trade entry</h2>
                <h1 class="trade">New trade entry</h1>
            </div>
    
            <div class="contents">
                <div class="clientDetails">
                    <label class="clientData">Client</label>
                        <select  id="client" name="clientcompany">
                            <option selected disabled>Select Client</option>
                                <?php while ($row = mysqli_fetch_assoc($county_qry)) : ?>
                                    <option value="<?php echo $row['id']; ?>"> <?php echo $row['clientcompany']; ?> </option>
                                <?php endwhile; ?>
                    </select>
                    
                </div>

            <div class="contractDetails">
                <label class="contractData">Contract</label>
                    <select id="contract" name='clientId'>
                        <option selected disabled>Select Contract</option>
                    </select>
                    <!-- <option id= "nusclient" class="clients" onchange="showdiv('parent', this)">NUS Client  </option> -->
            </div>

            <div class="headers">
                <div>
                    <span class="tradePeriod">Trade period</span>
                    <span class="year">Year</span>
      
                        <div class="wrappers">
                            <div class="boxs" id="yearbuttons" onclick="myFunction()">
                                <input type="radio" name="box" id="box1" checked="checked" >
                                    <div class="calendarYear">
                                        <button id="btn" class="calendar" onclick="myFunction()">Calendar year</button>
                                    </div>  
                                    

                                <input type="radio" name="box" id="box2">
                                    <div class="season" id="y">
                                        <button class="seasons" onclick="myFunction()" >Season</button>
                                    </div>
                                    <div class = "yearseason"  id='ys' style="display:none" >
                                            <button id="ys">Q1</button>
                                    </div>
                                <input type="radio" name="box" id="box3">
                                    <div class="calendarQuarters">
                                        <button class="calandarquarter">Calendar Quaters</button>
                                    </div>
                
                                <input type="radio" name="box" id="box4">
                                    <div class="calendarMonths">
                                        <button class="calendarmonth">Calendar months</button>
                                    </div>
                                <!-- <h4 class="year">Year</h4> -->
                                
                                <div>
                                    <select id="ddlYears">
                                        <option>Select the year</option>
                                    </select>
                                </div>
                            </div>
                        </div>    
                    </div>                        
                        
                        <div class="baseload">
                            <label for="baseLoad" class= "loadprice">Base load price</label>
                            <br>
                            <input type="text" placeholder="0.00">
                        </div>
                        
                        <div class="effectiveprice">
                            <label for="effectiveprice" class="effectiveprice">Effective price</label>
                            <br>
                            <input type="text" placeholder="0.00"> 
                        </div>
                    
                            <button class="enterTradebtn">Enter trade</button>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</body>
<script>
    // County State

    $('#client').on('change', function() {
        var clientId = this.value;
        console.log(clientId);
        $.ajax({
            url: 'ajax/contract.php',
            type: "POST",
            data: {
                country_data: clientId
            },
            success: function(result) {
                $('#contract').html(result);
                // console.log(result);
            }
        })
    });

</script>


<script type="text/javascript">
    window.onload = function () {
        //Reference the DropDownList.
        var ddlYears = document.getElementById("ddlYears");
 
        //Determine the Current Year.
        var currentYear = (new Date()).getFullYear();
        currentYear += 30;
 
        //Loop and add the Year values to DropDownList.
        for (var i = 1950; i <= currentYear; i++) {
            var option = document.createElement("OPTION");
            option.innerHTML = i;
            option.value = i;
            ddlYears.appendChild(option);
        }
    };
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</html>