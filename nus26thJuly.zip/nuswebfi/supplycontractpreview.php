<?php
    include('security.php');
    include('dbconn.php')
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS FRS System | Supply Contract</title>
    <link rel="icon" href="img/social-square-n-blue.png" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/stylenew.css" />
     <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.standalone.min.css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet"/>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

</head>
<style type="text/css">
.suplycnt{
    margin: 40px 0 0 300px;
}
/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}
#nextBtn{
  float: right;
}
/*input[type=range]{
  background: #E3EBF6;
  border: none;
}*/
/* Mark the active step: */
.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #04AA6D;
}
.cat{
  margin: 4px;
  
 /* overflow: hidden;*/
  float: left;
}

.cat label {
  float: left;
  line-height: 3.0em;
  width: 10.0em; 
  height: 3.0em;
  font-size: 13px!important;
}

.cat label span {
  text-align: center;
  padding: 3px 0;
  display: block;
  background-color: #fff;
  border-radius:6px; 

}

.cat label input {
  position: absolute;
  display: none;
 
}
/* selects all of the text within the input element and changes the color of the text */
/*.cat label input + span{color: #fff;}
*/

/* This will declare how a selected input will look giving generic properties */
.cat input:checked + span {
    color: #ffffff;
    
}

.disabledbutton {
   color: grey;
   border:1px solid grey;
    opacity: 0.5;
}

.cat label span img{
  filter: grayscale(100%);
}
.activebutton{
  color: #1363F1!important;
  border:1px solid #1363F1;
  opacity: 1;
}


label {
    color: #12263F;
    font-family: 'Segoe UI';
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 152.4%;
    /*display: flex;*/
    margin-bottom: 6px;
    align-items: center;
    letter-spacing: -0.01em;
    padding: 0px!important;
    /*margin: 0 0 -15px 0;*/
}
.catw{
    display: inline-block;
}
.padmd0 h3{
  margin-top: 6px;
  font-size: 26px;
}
.padmd0 select{
  border:1px solid lightgrey;
  box-shadow: none;
  color: #000;
  height: 38px!important;
}
.padmd0 h6{
  text-transform: uppercase;
  color: grey;
  font-size: 10px;
  letter-spacing: 1px;
}
.switch {
  display: inline-block;
  height:27px;
  position: relative;
  width: 55px;
  top: 14px;
}

.switch input {
  display:none;
}

.switchs {
  display: inline-block;
  height: 27px;
  position: relative;
  width: 55px;
  top: 14px;
}

.switchs input {
  display:none;
}

.sliders {
  background-color: #ccc;
  bottom: 0;
  cursor: pointer;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  transition: .4s;
}

.sliders:before {
  background-color: #fff;
  bottom: 4px;
  content: "";
  height: 20px;
  left: 4px;
  position: absolute;
  transition: .4s;
  width: 20px;
}

input:checked + .sliders {
  background-color: #1363F1;
}

input:checked + .sliders:before {
  transform: translateX(26px);
}

.sliders.rounds {
  border-radius: 34px;
}

.sliders.rounds:before {
  border-radius: 50%;
}

.slider {
  background-color: #ccc;
  bottom: 0;
  cursor: pointer;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  transition: .4s;
}

.slider:before {
  background-color: #fff;
  bottom: 4px;
  content: "";
  height: 20px;
  left: 4px;
  position: absolute;
  transition: .4s;
  width: 20px;
}

input:checked + .slider {
  background-color: #1363F1;
}

input:checked + .slider:before {
  transform: translateX(26px);
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
.contrac{
    background: white;
    border-radius: 8px;
}
.client{
    position: relative;
}
.searchs{
    position: absolute;
    top: 5px;
    left: 3px;
    width: 10%;
}
.page select{
    font-size: 10px;
    padding: 7px!important;
}
.flitr{
    position: absolute;
    right: 5px;
    top: 5px;
}
.fullwidth{
  width: 100%;
  float: unset!important;
}
.clientbr ul{
    padding-inline-start:0px;
}
.clientbr ul li{
    display: inline;
}
.clientbr ul li a{
    padding: 7px;
    text-decoration: none;
}
.client input[type="text"]{
    padding-left: 25px;
}
.units{
  display: none;
}
.indexcl{
  display: none;
}
.page{
    position: absolute;
    right: 15%;
    top: 5px;
}
.sttab{
  width: 77%;
}
.bfg{
  height: 1px;
  background-color: lightgrey;
}
div label input {margin-right: 100px;}
/*
This following statements selects each category individually that contains an input element that is a checkbox and is checked (or selected) and chabges the background color of the span element.
*/
.action input:hover +span{
  background-color: #fff;
  color: blue;
  border:1px solid blue;
}
.action input:hover +span{
  background-color: #fff;
  opacity: 1;
  color: #1363F1;
  border: 1px solid #1363F1;
}
.action input:hover +span img{
  filter: invert(25%) sepia(94%) saturate(3383%) hue-rotate(215deg) brightness(98%) contrast(92%);
}
.action input:checked + span{
  background-color: #fff;
  opacity: 1;
  color: #1363F1;
  border: 1px solid #1363F1;
}
.action input:checked + span img{
  filter: invert(25%) sepia(94%) saturate(3383%) hue-rotate(215deg) brightness(98%) contrast(92%);
}

/*form {
    width: 400px;
    padding: 30px;
    border-radius: 15px;
    margin: 80px 0 0 0;
}*/
.chosen-container-single .chosen-single{
    height: 35px!important;
    padding: 6px 0px 0px 8px!important;
}
.tab {
        display: none;
      }
.widse{
    width:100%;
    margin: auto;
}
      .tab img {
        margin: 3px;
      }
      .padmd0{
   
    position: absolute;
    width: 46%;
    left: 58%;
    top: 5%;
    transform: translate(-50%, 0%);
}
body{
  background: #F9FBFD;
}
input[type=range] {
  -webkit-appearance: none;
  margin: 0px 0;
  width: 100%;
  border: none;
  background: #F9FBFD;
}
input[type=range]:focus {
  outline: none;
}
input[type=range]::-webkit-slider-runnable-track {
  width: 100%;
  height: 5px;
  cursor: pointer;
 
  background: #E3EBF6;
  border-radius: 1.3px;
  
}
input[type=range]::-webkit-slider-thumb {
  box-shadow: 1px 1px 1px rgba(0,0,0,0.5);
  border: 3px solid #fff;
  height: 17px;
  width: 17px;
  border-radius: 50%;
  background: #1363F1;
  
  cursor: pointer;
  -webkit-appearance: none;
  margin-top: -8px;
}
.allowdvi{
  padding-top: 24px;
}
input[type=range]:focus::-webkit-slider-runnable-track {
  background: #E3EBF6;
}
.diviy p{
  margin-bottom: 0px;
}
input[type=range]::-moz-range-track {
  width: 100%;
  height: 8.4px;
  cursor: pointer;
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
  background: #3071a9;
  border-radius: 1.3px;
  border: 0.2px solid #010101;
}
input[type=range]::-moz-range-thumb {
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
  border: 1px solid #000000;
  height: 36px;
  width: 16px;
  border-radius: 3px;
  background: #ffffff;
  cursor: pointer;
}
input[type=range]::-ms-track {
  width: 100%;
  height: 8.4px;
  cursor: pointer;
  background: transparent;
  border-color: transparent;
  border-width: 16px 0;
  color: transparent;
}
input[type=range]::-ms-fill-lower {
  background: #2a6495;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
}
input[type=range]::-ms-fill-upper {
  background: #3071a9;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
}
input[type=range]::-ms-thumb {
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
  border: 1px solid #000000;
  height: 36px;
  width: 16px;
  border-radius: 3px;
  background: #ffffff;
  cursor: pointer;
}
input[type=range]:focus::-ms-fill-lower {
  background: #E3EBF6;
}
input[type=range]:focus::-ms-fill-upper {
  background: #E3EBF6;
}
</style>
<body>
    <div class="main">
        <div class="menu">

            <?php
                include('sidebar.php');
                include('includes/functions.php');
                $functions = new libFunc();
            ?>
        </div>
    <div>
     <div class="contentMove">
        <div class="suplycnt">

          <?php

          $editsingledata = array();
          $getsupplydetails = "SELECT * FROM nus_supply_contract WHERE supplierId=".$_GET['id']."";

          

          $result = $conn->query($getsupplydetails);
              if ($result->num_rows > 0) {
                  while($row = $result->fetch_assoc()) {
                      $editsingledata[] = $row;
                  }
          }

         // echo "<h1>".$editsingledata[0]['countryName']."</h1>";
          

          $getclientdata = $functions->getclientdata($editsingledata[0]['clientId']);
      
          ?>
            
            <div class="padmd0">
              <form id="regForm" action="insertSupplycontract.php?type=edit&id=<?=$_GET['id']?>" method="POST">
                <!-- for contract details-->
              <div class="tab" id="contract">
                <h6>Edit Supply Contract</h6>
                <h3>Contract Details</h3>
                <hr>
                <input type="hidden" class="edittab" value="normal">
                <label>Client</label>
                <select class="chosen-select form-control clint" name="client" onchange="getclientdetails(this.value)">
                 
                      <?php
                      
                      $getclientdetails =array();
                      $getsupplydetails = "SELECT * FROM clientcompanydata";
                      $result = $conn->query($getsupplydetails);
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $getclientdetails[] = $row;
                            }
                        }
                      
                        foreach ($getclientdetails as $key => $value) {
                          $selected ='';
                          if($value['id'] == $editsingledata[0]['clientId']){
                            $selected = 'selected';
                          }
                          
                          ?>
                            <option value="<?=$value['id']?>" <?=$selected?>><?=$value['clientcompany']?></option>
                            
                        <?php
                        }
                        ?>
                </select>
                <input type="hidden" class="country" name="country" value="<?=$getclientdata[0]['countryName']?>">

                <input type="hidden" class="clientname" name="clientname" value="<?=$getclientdata[0]['clientcompany']?>">
                <div class="row">
                  <div class="col-md-6">
                    <label>Commodity</label><br>
                    
                    <div style="display: inline-block;">
                        <div class="cat action">
                         <label>
                            <input type="checkbox" value="electricity" name="commodity[]" class="commodity" 
                            <?php

                            if($editsingledata[0]['commodityName'] == 'electricity'){
                              echo 'checked';
                            }
                            ?>><span class="disabledbutton act"><img src="img/electricity-hover.svg" >Electricity</span>
                         </label>
                      </div>
                      <div class="cat action">
                         <label>
                            <input type="checkbox" value="natural gas"  name="commodity[]" class="commodity"
                            <?php

                            if($editsingledata[0]['commodityName'] == 'natural gas'){
                              echo 'checked';
                            }
                            ?>
                            ><span class="disabledbutton dis"><img src="img/naturalgas.svg" > Natrual Gas</span>
                         </label> 
                      </div>
                    </div>
                  </div>
                  
                  <?php
                  $class='units';
                  if($editsingledata[0]['commodityName'] == 'natural gas'){
                      $class ='displayblck';
                  }
                  ?>
                  <div class="col-md-6 <?=$class?>" >
                    <label>units</label><br>
                    <div class="natru" style="display: inline-block;">
                      <div class="cat action">
                        <label>
                            <input type="checkbox" value="MWh_GE" name="units[]" class="unit" 
                             <?php
                             if($editsingledata[0]['commodityUnits'] == 'MWh'){
                              echo 'checked';
                             }
                             ?>
                            ><span class="disabledbutton dis">MWh</span>
                             
                        </label>
                      </div>
                      <div class="cat action">
                         <label>
                            <input type="checkbox" value="Therms" name="units[]" class="unit" 
                            <?php
                             if($editsingledata[0]['commodityUnits'] == 'Therms'){
                              echo 'checked';
                             }
                             ?>
                            ><span class="disabledbutton dis">Therms</span>
                         </label>
                      </div>
                    </div>
                  </div>
                
                </div>
                <div ><br>
                  <label>Supplier</label>
                  <input type="text" class="form-control supplr" name="supplr" value="<?=$editsingledata[0]['supplyName']?>">
                  
                </div><br>
                 <div >
                  <label>Contract Commodity Price</label>
                  <select class="form-control contractprice" name="contractprice">
                    <option value="Euro" 
                    <?php

                    if($editsingledata[0]['contractType'] == 'Euro'){
                      echo 'selected';
                    }
                    ?>
                    >Euro</option>
                    <option value="Pounds" 
                    <?php

                    if($editsingledata[0]['contractType'] == 'Pounds'){
                      echo 'selected';
                    }
                    ?>
                    >Pounds</option>
                    <option value="Dollars" 
                    <?php

                    if($editsingledata[0]['contractType'] == 'Dollars'){
                      echo 'selected';
                    }
                    ?>
                    >Dollars</option>
                  </select>
                </div><br>
                <div class="row">
                  <div class="col-md-6">
                    <label>Contact Type</label><br>
                    <div style="display: inline-block;">
                        <div class="cat action">
                         <label>
                            <input type="checkbox" value="fixed" name="contacttype[]" class="contactType" 
                            <?php
                            if($editsingledata[0]['contractType'] == 'fixed'){
                              echo 'checked';
                            }
                            ?>
                            ><span class="disabledbutton dis">Fixed</span>
                         </label>
                      </div>
                      <div class="cat action">
                         <label>
                            <input type="checkbox" class="contactType" name="contacttype[]" value="indexed" 
                            <?php
                            if($editsingledata[0]['contractType'] == 'indexed'){
                              echo 'checked';
                            }
                            ?>
                            ><span class="disabledbutton dis">Indexed</span>
                         </label>
                      </div>
                    </div>
                  </div>
                  <input type="hidden" class="cttype" name="contType">
                  <?php
                  $getctype ='indexcl';
                  if($editsingledata[0]['contractType'] == 'indexed'){
                    $getctype= 'displayblck';
                  }
                  ?>
                  <div class="col-md-6 <?=$getctype?>">
                    <label>Index</label><br>
                    <select class="chosen-select indexType form-control" name="indexed">
                     
                      <option value="xlts" 
                      <?php
                      if($editsingledata[0]['contractType'] == 'xlts'){
                        echo 'selected';
                      }
                      ?>>xlts</option>
                    </select>
                  </div>
                </div>

              </div>
              <!-- for Length and consumption-->
              <div class="tab" id="length">
                  <h6>Edit Supply Contract</h6>
                <h3 class="dynamictext">
                  <?php
                  if($editsingledata[0]['contractType'] == 'fixed'){
                    echo 'Term, Consumption, and Price - Fixed Price Contract';
                  }else{
                    echo 'Term and Consumption - Indexed Contract';
                  }
                  ?>
                </h3>
                <hr>
                <label>Contract Term</label>
                <div class="input-group input-daterange">
                  <input id="startDate1" name="startDate1" type="text"
                    class="form-control startdate" onchange="calcualteMonthYr(this.value,$('.endate').val())" readonly="readonly" value="<?=date('Y/m/d',strtotime($editsingledata[0]['contractTermfromDate']))?>"> <span
                    class="input-group-addon">
                    <!--  <span
                    class="glyphicon glyphicon-calendar"></span> -->
                  </span> <span class="input-group-addon">to</span> <input id="endDate1"
                    name="endDate1" type="text"  value="<?=date('Y/m/d',strtotime($editsingledata[0]['contractTermtoDate']))?>" class="form-control endate" readonly="readonly" onchange="calcualteMonthYr($('.startdate').val(), this.value)">
                  <span class="input-group-addon">
                    
                  </span>
                </div><br>
               
                <?php
                
                $getmonthscout =explode(',', $editsingledata[0]['allmonts'])
                ?>
                <input type="hidden" class="countmonths" value="<?=count($getmonthscout)?>">
                <input type="hidden" class="allmonths" name="allmnts" value="<?=$editsingledata[0]['allmonts']?>">
                <?php
                $shoprice = 'units';
                if($editsingledata[0]['contractType'] != 'fixed'){
                    $shoprice ='displayblck';
                }

                ?>
                <div class="compr <?=$shoprice?>">
                  <label>Commodity Price</label>
                 
                  
                  <div class="input-group">
                      <input class="form-control left-border-none comdyprice" placeholder="$0.00" type="text" class="commodityprice" name="commodityprice" value="<?=$editsingledata[0]['commodityPrice']?>">
                      <span class="input-group-addon transparent">
                      MWh</span>
                      
                  </div>
                </div>
                <br>
                <div class="row">
                  <div class="col-md-6">
                    <label>Total annual Consumption</label>
                    <div class="input-group">
                        <input class="form-control left-border-none totalanualconsumption" placeholder="$0.00" type="text" name="totalanualconsumption" value="<?=$editsingledata[0]['totalAnualConsumption']?>">
                        <span class="input-group-addon transparent">
                        MWh</span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <label>Allocate Consumption per month</label>
                    <label class="switch" for="checkbox">
                        <input type="checkbox" id="checkbox" checked />
                        <div class="slider round"></div>
                      </label>
                  </div>
                </div>
                
                <label>Divide Equality between months</label>
                <label class="switchs" for="checkboxs">
                  <input type="checkbox" id="checkboxs" />
                  <div class="sliders rounds"></div>
                </label>
                <div class="allowdvi">
                  <?php
                  $anualTotal = $editsingledata[0]['totalAnualConsumption'];
                  $mnthscnt = count($getmonthscout);
                  $allmonths = $editsingledata[0]['allmonts'];
                  $allmonths = explode(',', $allmonths);

                  $getmnts = array();
                  for($j=0;$j<count($allmonths);$j++){
                     $splitmonth = explode('-', $allmonths[$j]);
                     array_push($getmnts,$splitmonth[1]);
                  }
                  $totalmonths = count($getmnts);
                  if($totalmonths>12){
                    $totalmonths = 12;
                  }
                  $yearDiv = $anualTotal/12;
        
                  $printdata = '';
                  $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                  $sumtotal = 0;
                 
                  for($i=0;$i<$totalmonths;$i++){
                    // echo $i;
                    // echo $months[$getmnts[$i]-1];
                    $printdata .="<div class='diviy'>";
                    $printdata .="<div class='row'>";
                    $printdata .='<div class="col-md-1">';
                    $printdata .='<p>'.$months[$getmnts[$i]-1].'</p>';
                    $printdata .='</div>';
                    $printdata .='<div class="col-md-6">';
                    $printdata .='<input type="range" id="points" class="rangslider" value="'.round($yearDiv).'" name="points" min="0" max="'.$anualTotal.'" onchange="showVal(this.value,'.$i.')">';
                    $printdata .='</div>';
                    $printdata .='<div class="col-md-5">';
                    $printdata .='<div class="input-group">';
                    $printdata .='<input class="months'.$i.'"  type="hidden" value="'.$months[$getmnts[$i]-1].'">';
                    $printdata .='<input class="form-control left-border-none peryr peryearval'.$i.'" placeholder="$0.00" type="text" value="'.$yearDiv.'">';
                    $printdata .='<span class="input-group-addon transparent">MWh</span></div>';
                    $printdata .='</div>';
                    $printdata .='</div>';
                    $printdata .='</div>';
                    $sumtotal +=$yearDiv;
                  }
                  $printdata .='<hr>';
                  $printdata .='<div class="row">';
                  
                  $printdata .='<div class="col-md-8">';
                  $printdata .='<h3>Total Annual Consumptions</h3>';
                  $printdata .='</div>';
                  $printdata .='<div class="col-md-4 text-right">';
                  $printdata .='<span style="color:red" class="errormax"></span>';
                  $printdata .='<input type="hidden" name="totlcnsumtion" class="totlcnsumtion" value="'.$sumtotal.'">';
                  $printdata .='<h3><span class="anuTolal">'.$sumtotal.'</span> MWH</h3>';
                  $printdata .='</div>';
                  $printdata .='</div>';
                  echo $printdata;
      
              ?>
                  
                </div>
                
                
              </div>

              <div class="tab indexdex" id="index">
                <h6>Edit Supply Contract</h6>
                <h3>Index Details</h3>
                <hr>
                  <label>Index Structure Type</label><br>
                  <div style="display: inline-block;">
                  <div class="cat action">
                    <label>
                      <input type="checkbox" class="indexstr" name="indexstr[]" value="Consumption(MWh)" 
                      checked><span class="disabledbutton dis">Consumption(MWh)</span>
                    </label>
                  </div>
                  <div class="cat action">
                    <label>
                      <input type="checkbox" class="indexstr" name="indexstr[]" value="Power(MW)" 
                       ><span class="disabledbutton dis">Power(MW)</span>
                    </label>
                  </div>
                </div>
                
                <div class="alrw">
                  <label>Allowable trade periods</label><br>
                      <a onclick="addTradeperiods()"class="btn btn-default">add allowable trade periods</a><br>
                      
                  <?php
                  $getTradableprice = array();
                  $getallowabletrade = "SELECT * FROM nus_tradeperiods WHERE supplierId =".$_GET['id']."";
                  $result = $conn->query($getallowabletrade);
                  if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                      $getTradableprice[] = $row;
                      
                    }
                  }
                  
                  ?>
                 <input type="hidden" class="rowcount" value="<?=count($getTradableprice)?>" name="rowcount">
                  <div class="addTrade">

                     <?php
                     foreach ($getTradableprice as $key => $value) {
                     ?>
                        <div class="trade<?=$key?>">
                            <div class="row">
                                <div class="col-md-7">
                                </div>
                                <div class="col-md-5">
                                <label>Clicks/tranches</label><br>           
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <select class="chosen-select tradsel<?=$key?>" name="tradsel<?=$key?>">
                                        
                                        <option value="Calendar Yearly" 
                                        <?php
                                        if($value['periodsId'] == 'Calendar Yearly'){
                                          echo 'selected';
                                        }
                                        ?>>Calendar Year</option>
                                        <option value="Calendar Quarterly" 
                                        <?php
                                        if($value['periodsId'] == 'Calendar Quarterly'){
                                          echo 'selected';
                                        }
                                        ?>
                                        >Calendar Quarter</option>
                                        <option value="Calendar Monthly" 
                                        <?php
                                        if($value['periodsId'] == 'Calendar Monthly'){
                                          echo 'selected';
                                        }
                                        ?>
                                        >Calendar Monthly</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control tranche<?=$key?>" name="tranche<?=$key?>" value="<?=$value['clicktracnches']?>">
                                </div>
                                <div class="col-md-2"><i class="fa fa-trash-o" onclick="removerow(<?=$key?>)" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="row">
                                <label>Clicks/tranche minimum size</label><br>
                                <div class="input-group">
                                  <span class="input-group-addon transparent" style="width: 30%;">
                                    <select class="clnmin minsize<?=$key?>" name="minsize<?=$key?>">
                                        <option value="% consumption" 
                                        <?php
                                        if($value['clicktranches'] == '% consumption'){
                                          echo 'selected';
                                        }
                                        ?>>% consumption</option>
                                        <option value="#MWhs" 
                                        <?php
                                        if($value['clicktranches'] == '#MWhs'){
                                          echo 'selected';
                                        }
                                        ?>
                                        >#MWhs</option>
                                    </select>
                                  </span>
                                  <input class="form-control left-border-none minsizevalue<?=$key?>" name="minsizevalue<?=$key?>" value="<?=$value['tranchesvalue']?>" type="text">
                                  <span class="input-group-addon transparent"> %</span>
                                </div>
                            </div>
                        </div>
                      <hr>
                  <?php
                }
                  ?>
                  </div>

                </div>
              
                
                
                <label>Open Position pricing mechanism</label><br>
                <select class="chosen-select pricMech" name="openmech">
                  <?php
                    $getUserfields =array();
                    $getsupplydetails = "SELECT * FROM nus_pricing_mechanisam ";
                    $result = $conn->query($getsupplydetails);
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $getUserfields[] = $row;
                            }
                        }
                       
                        foreach ($getUserfields as $key => $value) {
                          $selected = '';
                          
                            if($value['pricingMechName'] == $editsingledata[0]['openPrizemechanism']){
                              $selected = 'selected';
                            
                          }
                          ?>
                            <option value="<?=$value['pricingMechName']?>" <?=$selected?>><?=$value['pricingMechName']?><br><?=$value['priceMechDesc']?></option>
                            
                        <?php
                        }
                        ?>
                  
                </select>
              </div>

              <div class="tab" id="preview">
                <?php
                if(isset($_SESSION['updated'])&&((time() - $_SESSION['updated']) < 2)) {
                  
                  echo '<script> toastr.success("successfully Updated", "Supply contract ");</script>';
                  if((time() - $_SESSION['updated']) > 2){
                      unset($_SESSION['updated']);
                  }
                } 
                
               ?>     
                 <h6>New Supply Contract</h6>
                <h3>Contract Preview</h3>
                <hr>
                <div class="contrac preview1">
                  <div class="row">
                    <div class="col-md-6">
                      <h6>Contract Details</h6>
                    </div>
                    <div class="col-md-6 text-right">
                      <?php
                      if($_GET['type']=='edit'){
                        if($_SESSION['role'] == 'Admin' || $_SESSION['role'] == 'NUS Manager' || $_SESSION['role'] == 'NUS User'){
                      ?>
                      <a class="btn btn-primary" onclick="showTabs(0,3)">Edit</a>
                      <?php
                    }
                    }
                      ?>
                    </div>
                  </div>
                  <table class="table">
                  <tr>
                    <td>Client</td>
                    <td><?=$getclientdata[0]['clientcompany']?></td>
                  </tr>
                  <tr>
                    <td>Country</td>
                    <td><?=$editsingledata[0]['countryName']?></td>
                  </tr>
                  <tr>  
                    <td>Commodity</td>
                    <td><?=$editsingledata[0]['commodityName']?></td>
                  </tr>
                  <tr>
                    <td>Supplier</td>
                    <td><?=$editsingledata[0]['supplyName']?></td>
                  </tr>
                  <tr>
                      <td>Contract Type</td>
                      <td><?=$editsingledata[0]['contractType']?></td>
                  </tr>
                  <?php
                  if($editsingledata[0]['contractType'] != "fixed"){?>
                    <tr>

                    <td>Index name</td>
                    <td><?=$editsingledata[0]['contractIndexId']?></td>
                    </tr>
                  <?php
                  }
                  ?>
                  <tr>
                    <td>Contract Commodity Currency</td>
                    <td><?=$editsingledata[0]['contractpricetype']?></td>
                  </tr>
                    </table>
        
       
         
                </div>

                <div class="contrac preview2">
                    
                  <div class="row">
                      <div class="col-md-6">
                        <h6>Length Consumption</h6>
                      </div>
                      <div class="col-md-6 text-right">
                        <?php
                      if($_GET['type']=='edit'){
                        if($_SESSION['role'] == 'Admin' || $_SESSION['role'] == 'NUS Manager' || $_SESSION['role'] == 'NUS User'){
                      ?>
                          <a class="btn btn-primary" onclick="showTabs(1,3)">Edit</a>
                          <?php
                        }
                      }
                          ?>
                      </div>
                  </div>
                  <table class="table">
                  <tr>
                    <td>Contract Term</td>
                    <td><?=$editsingledata[0]['contractTermfromDate'].'-'.$editsingledata[0]['contractTermtoDate']?></td>
                  </tr>
                  <?php
                  if($editsingledata[0]['contractType'] =='fixed'){
                  ?>
                  <tr>
                    <td>Commodity Price</td>
                    <td><?=$editsingledata[0]['commodityPrice']?></td>
                  </tr>
                  <?php
                  }
                  ?>
                  
                  <tr>
                      <td>Total Anual Consumption</td>
                      <td><?=$editsingledata[0]['totlconsumption']?></td>
                  </tr>
                  
                    <?php
                    $allmonths = $editsingledata[0]['allmonts'];
                  $allmonths = explode(',', $allmonths);

                  $getmnts = array();
                  for($j=0;$j<count($allmonths);$j++){
                     $splitmonth = explode('-', $allmonths[$j]);
                     array_push($getmnts,$splitmonth[1]);
                  }
                  $totalmonths = count($getmnts);
                  if($totalmonths>12){
                    $totalmonths = 12;
                  }
                  
        
                  
                for($i=0;$i<$totalmonths;$i++){?>
                  <tr>
                    <td><?=$months[$getmnts[$i]-1]?> Consumption</td>
                    <td><?=$yearDiv?></td>
                  </tr>
                  
                <?php
                }
                ?>

                  </table>
        
                </div>
                <div class="contrac preview3">
                </div>
                <?php
                if($editsingledata[0]['contractType'] !='fixed'){
                ?>
                <div class="contrac preview3">
        
                  <div class="row">
                      <div class="col-md-6">
                        <h6>Index Details</h6>
                      </div>
                      <div class="col-md-6 text-right">
                         <?php
                      if($_GET['type']=='edit'){
                        if($_SESSION['role'] == 'Admin' || $_SESSION['role'] == 'NUS Manager' || $_SESSION['role'] == 'NUS User'){
                      ?>
                          <a class="btn btn-primary" onclick="showTabs(2,3)">Edit</a>
                          <?php
                        }
                      }
                          ?>
                      </div>
                  </div>
                  <table class="table">
                  <tr>
                      <td>Index Structure</td>
                      <td><?=$editsingledata[0]['indexStructureType']?></td>
                  </tr>
                  <?php
                  $allowabletrade =array();
                  $geminsize = array();
                  $getallowabletrade = "SELECT * FROM nus_tradeperiods WHERE supplierId =".$_GET['id']."";
                  $result = $conn->query($getallowabletrade);
                  if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                      $allowabletrade[] = $row['periodsId'].'-'.$row['clicktracnches'];
                      $geminsize[] =  $row['clicktranches'].'-'.$row['tranchesvalue'];
                    }
                  }
                  ?>
                  <tr>
                      <td>Allowable Trade Periods</td>
                      <td><?=implode(',',$allowabletrade)?></td>
                  </tr>
       <!--  var tradeper = parsedObject.allowperiod;
        var arrayval = tradeper.split(",");
        parsedObject.cons = consumption.toString();
        

        console.log(arrayval);
        var consum = ['% consumption','#MWhs'];
        for(var key in parsedObject){
          if(arrayval.includes(key)){
            printthreedata +='<tr>';
            printthreedata +='<td>'+key+' clicks / Tranches</td>';
            printthreedata +='<td>'+parsedObject[key]+'</td>';
            printthreedata +='</tr>';
          }
          // if(consum.includes(key)){
          //   printthreedata +='<tr>';
          //   printthreedata +='<td>clicks / Tranches Minimum size ('+key+')</td>';
          //   printthreedata +='<td>'+parsedObject[key]+'</td>';
          //   printthreedata +='</tr>';
          // }
         -->
       <!--  } -->
                    <tr>
                        <td>clicks / Tranches Minimum size </td>
                        <td><?=implode(',',$geminsize)?></td>
                    </tr>
                    <tr>
                      <td>Open Position Pricing Mechanism</td>
                      <td><?=$editsingledata[0]['openPrizemechanism']?></td>
                    </tr>

                  </table>
        
                </div>
                <?php
                  }
                    ?>
              </div>
              <?php
              if($_GET['type'] == 'edit'){
              ?>
              <div style="overflow:auto;">
                <div class="testing" >
                  
                  <button type="button" id="nextBtn" class="btn btn-primary" onclick="nextPrev(1,'next')">continue <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
</button>
                  <button type="button" id="prevBtn" class="btn btn-default" onclick="nextPrev(-1,'previous')"><i class="fa fa-long-arrow-left" aria-hidden="true"></i><i class="fa fa-long-arrow-left" aria-hidden="true"></i>
 Previous</button>
                  <button type="button" id="cancelBtn" class="btn btn-default" onclick="window.location.href='index.php'"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Cancel </button>
                </div>
              </div>
              <?php
            }
              ?>
              

            </form>
        </div>
        </div>
    </div>
<script
    src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
       $('.input-daterange').datepicker({
              });
      
    });
    



    $('#checkbox').on('click',function(){
      if($(this).is(':checked')){
        
        var anualTotal = $('.totalanualconsumption').val();
        var countdiv = $('.countmonths').val();
        var allmonths = $('.allmonths').val();
            allmonths = allmonths.split(',');
            console.log(allmonths);
        var getmnts = [];
        for(var j=0;j<allmonths.length;j++){
            var splitmonth = allmonths[j].split('-');
            getmnts.push(splitmonth[1]);
        }
        var totalmonths = getmnts.length;
        if(totalmonths>12){
          totalmonths = 12;
        }
        console.log(getmnts);
        var yearDiv = parseInt(anualTotal)/12;
        var printData = '';

        var months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
        var sumtotal = 0;
        for(var i=0;i<totalmonths;i++){
          printData +='<div class="diviy">';
          printData +='<div class="row">';
          printData +='<div class="col-md-1">';
          printData +='<p>'+months[getmnts[i]-1]+'</p>';
          printData +='</div>';
          printData +='<div class="col-md-6">'
          printData +='<input type="range" id="points" class="rangslider" value="'+Math.round(yearDiv)+'" name="points" min="0" max="'+parseInt(anualTotal)+'" onchange="showVal(this.value,'+i+')">';
          printData +='</div>';
          printData +='<div class="col-md-5">';
          printData +='<div class="input-group">';
          printData +='<input class="months'+i+'"  type="hidden" value="'+months[getmnts[i]-1]+'">';
          printData +='<input class="form-control left-border-none peryr peryearval'+i+'" placeholder="$0.00" type="text" value="'+yearDiv+'">';
          printData +='<span class="input-group-addon transparent">MWh</span>';
          printData +='</div>';
          printData +='</div>';
          printData +='</div>';
          sumtotal +=yearDiv;
        }
        printData +='<hr>';
        printData +='<div class="row">';
        
        printData +='<div class="col-md-8">';
        printData +='<h3>Total Annual Consumptions</h3>';
        printData +='</div>';
        printData +='<div class="col-md-4 text-right">';
        printData +='<span style="color:red" class="errormax"></span>';
        printData +='<input type="hidden" name="totlcnsumtion" class="totlcnsumtion" value="'+sumtotal+'">'
        printData +='<h3><span class="anuTolal">'+sumtotal+'</span> MWH</h3>';
        printData +='</div>';
        printData +='</div>';
        $('.allowdvi').html(printData);
      }else{
        $('.allowdvi').html('');
      }
    })
    $('#checkboxs').on('click',function(){
      if($(this).is(':checked')){
        $('.diviy').each(function(){
            $(this).find('.rangslider').prop('disabled',true);
            $(this).find('.peryr').attr('readonly',true);
          
        })
      }else{
        $('.diviy').each(function(){
          
            $(this).find('.rangslider').prop('disabled',false);
            $(this).find('.peryr').attr('readonly',false);
          
        })
      }
    });
    function showVal(rangeval, rowval){
      var total = 0;
      $('.peryr').each(function(){
        total +=parseInt($(this).val());
      })
      var totalCns = parseInt($('.totalanualconsumption').val());
      $('.anuTolal').html(total);
      if(total>totalCns){
        $('.errormax').html('Exceed Anual Consumption');
      }else{
        $('.errormax').html('');
      }
      $('.peryearval'+rowval).val(rangeval);
    }
    
  </script>


 <script>
var previeew ="<?php echo $_GET['type']?>";
console.log(previeew);
var currentTab = 0; 
if(previeew == 'preview' || previeew == 'edit'){
currentTab = 3;
}
showTab(currentTab); 
function showTab(n) {

  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  var contractType = $('.contactType:checked').val();
  $('.cttype').val(contractType);

  if (n == 0) {
    document.getElementById("cancelBtn").style.display = "inline";
    document.getElementById("cancelBtn").innerHTML = '<i class="fa fa-long-arrow-left" aria-hidden="true"></i> cancel ';
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("cancelBtn").style.display = "none";
    document.getElementById("prevBtn").innerHTML = '<i class="fa fa-long-arrow-left" aria-hidden="true"></i> previous ';
    document.getElementById("prevBtn").style.display = "inline";
  }
  var editval = $('.edittab').val();
  if(contractType == 'fixed'){
    
    $('.dynamictext').html('Term, Consumption, and Price - Fixed Price Contract');
    
    if (n == (x.length-1)) {
      
      x[n].style.display = "block";
      document.getElementById("prevBtn").style.display = "block";
      document.getElementById("nextBtn").innerHTML = "Update Contract";
      // $('#nextBtn').addClass('fullwidth');
 

      
    }else {
      if(n==2 && editval =='normal'){
          $(x[n]).remove();

      }
      if(n==2){
        x[n].style.display = "block";
        document.getElementById("nextBtn").innerHTML = "Update Contract";
      }else{
        document.getElementById("nextBtn").innerHTML = 'continue <i class="fa fa-long-arrow-right" aria-hidden="true"></i>';
      }
      
      
     
    }
  }
  else{
    if($('.indexdex').length==0){
      var print ='';
          print +='<div class="tab indexdex" id="index">';
          print +='<h6>New Supply Contract</h6>';
          print +='<h3>Index Details</h3>';
          print +='<hr>';
          print +='<label>Index Structure Type</label><br>';
          print +='<div style="display: inline-block;">';
          print +='<div class="cat action">';
          print +='<label>';
          print +='<input type="checkbox" class="indexstr" name="indexstr[]" value="Consumption(MWh)" checked><span class="disabledbutton dis">Consumption(MWh)</span>';
          print +='</label>';
          print +='</div>';
          print +='<div class="cat action">';
          print +='<label>';
          print +='<input type="checkbox" class="indexstr" name="indexstr[]" value="Power(MW)" ><span class="disabledbutton dis">Power(MW)</span>';
          print +='</label>';
          print +='</div>';
          print +='</div>';
                
          print +='<div class="alrw">';
          print +='<label>Allowable trade periods</label><br>';
          print +='<a onclick="addTradeperiods()"class="btn btn-default">add allowable trade periods</a><br>';
          print +='<input type="hidden" class="rowcount" value="1" name="rowcount">';
          print +='<div class="addTrade">';
                    
          print +='</div>';

          print +='</div>';
               
                
                
          print +='<label>Open Position pricing mechanism</label><br>';
          print +='<select class="chosen-select pricMech" name="openmech">';
          print +='<option value="Day Ahead,Spot Daily Market">Day Ahead,Spot Daily Market</option>';  
          print +='<option value="Day Ahead,Spot Average for month">Day Ahead,Spot Average for month</option>';
          print +='<option value="Month Ahead,Last Value">Month Ahead,Last Value</option>';
          print +='<option value="Month Ahead,Average Value">Month Ahead,Average Value</option>';
          print +='<option value="Quarter Ahead,Last Value">Quarter Ahead,Last Value</option>';
          print +='<option value="Quarter Ahead,Average Value">Quarter Ahead,Average Value</option>';
          print +='<option value="Calendar Ahead,Last Value">Calendar Ahead,Last Value</option>';
          print +='</select>';
          print +='</div>';
      $(x[x.length-2]).after(print);
    }
     $('.dynamictext').html('Term and Consumption - Indexed Contract');
     if (n == (x.length - 1)) {
      document.getElementById("prevBtn").style.display = "block";
      document.getElementById("nextBtn").innerHTML = "Update Contract";
      // $('#nextBtn').addClass('fullwidth');
      

    } else {

      document.getElementById("nextBtn").innerHTML = 'continue <i class="fa fa-long-arrow-right" aria-hidden="true"></i>';
    }
}
  
}
function showfrontTab(current){
  var x = document.getElementsByClassName("tab");
  
  x[current].style.display='block';
  x[1].style.display='none';
  x[2].style.display='none';
  x[3].style.display='none';
  if (current == 0) {
    currentTab = current;
    document.getElementById("cancelBtn").style.display = "inline";
    document.getElementById("prevBtn").style.display = "none";
    $('#nextBtn').removeClass('fullwidth');
    
  } 
  if (current == (x.length - 1)) {
    document.getElementById("prevBtn").style.display = "none";
    document.getElementById("nextBtn").innerHTML = "Continue";
    $('#nextBtn').addClass('fullwidth');

  } else {

    document.getElementById("nextBtn").innerHTML = 'continue <i class="fa fa-long-arrow-right" aria-hidden="true"></i>';
  }
}
function showTabs(n,current){
   
  var x = document.getElementsByClassName("tab");
   var contractType = $('.contactType:checked').val();
  x[n].style.display='block';

   x[current].style.display='none';
   if(contractType == 'fixed'){
    $('.edittab').val('normal');
   }else{
     $('.edittab').val('edit');
   }
  
  if (n == 0) {
    currentTab = n;
    document.getElementById("cancelBtn").style.display = "inline";
    document.getElementById("prevBtn").style.display = "none";
    $('#nextBtn').removeClass('fullwidth');
    
  } else {
    currentTab = n;
    document.getElementById("cancelBtn").style.display = "none";
    document.getElementById("prevBtn").style.display = "inline";
    $('#nextBtn').removeClass('fullwidth');
  }
  document.getElementById("nextBtn").innerHTML = 'continue <i class="fa fa-long-arrow-right" aria-hidden="true"></i>';

}

function nextPrev(n,type) {
  
  var x = document.getElementsByClassName("tab");
  var contractType = $('.contactType:checked').val();
  
  if(type=='next'){
    var obj = {};
    if(currentTab == 0){
      var clint = $('.clientname').val();
      var unit = '';
      if($('.commodity:checked').val() == 'natural gas'){
          unit = $('.unit:checked').val();
      }
      var commodity =$('.commodity:checked').val(); 
      var supplier = $('.supplr').val();
      obj.country = $('.country').val();
      var index = '';
      if($('.contactType:checked').val() == 'indexed'){
          index = $('.indexType').val();
      }
      var contractType = $('.contactType:checked').val();
      var startDate = $('.startdate').val();
      var endDate = $('.enddate').val();
      obj.client = clint;
      obj.commodity = [{name:commodity,unit:unit}];
      obj.supplier = supplier;
      obj.contracttype = [{type:contractType, index: index}];
      localStorage.setItem('obj', JSON.stringify(obj));
      
     
    }
     var contractType = $('.contactType:checked').val();
      if(contractType == 'fixed'){
        $('.compr').show();
       
      }else{
        $('.compr').hide();
        
      }
   
    
      if(currentTab == 1){

        var retrievedObject = localStorage.getItem('obj');
        var parsedObject = JSON.parse(retrievedObject);
        parsedObject.contractterm = $('.startdate').val()+'-'+$('.endate').val();
        parsedObject.comodityprice = $('.comdyprice').val();
        parsedObject.totalanualconsumption = $('.totlcnsumtion').val();
        parsedObject.contractprice = $('.contractprice').val();
        var countdiv = $('.countmonths').val();
        var allmonths = $('.allmonths').val();
            allmonths = allmonths.split(',');
           
        var getmnts = [];
        for(var j=0;j<allmonths.length;j++){
            var splitmonth = allmonths[j].split('-');
            getmnts.push(splitmonth[1]);
        }
        console.log(getmnts);
        
         var totalmonths = getmnts.length;
        if(totalmonths>12){
          totalmonths = 12;
        }
        var months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];

        for(i=0;i<totalmonths;i++){
          var value = $('.months'+i).val();
          var vals = value+"consumption";
          parsedObject[vals]= $('.peryearval'+i).val();
        }
        localStorage.setItem('obj', JSON.stringify(parsedObject));
        var contractType = $('.contactType:checked').val();

        if(contractType == 'fixed'){
          console.log(parsedObject);
          var printdata = '';
        printdata +='<div class="row">';
        printdata +='<div class="col-md-6">';
        printdata +='<h6>Contract Details</h6>';
        printdata +='</div>'
        printdata +='<div class="col-md-6 text-right">'
        printdata +='<a class="btn btn-primary" onclick="showTabs(0,2)">Edit</a>';
        printdata +='</div>';
        printdata +='</div>';
        printdata +='<table class="table">';
        printdata +='<tr>';
        printdata +='<td>Client</td>';
        printdata +='<td>'+parsedObject.client+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Country</td>';
        printdata +='<td>'+parsedObject.country+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Commodity</td>';
        printdata +='<td>'+parsedObject.commodity[0].name+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Supplier</td>';
        printdata +='<td>'+parsedObject.supplier+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Contract Type</td>';
        printdata +='<td>'+parsedObject.contracttype[0].type+'</td>';
        printdata +='</tr>';
        if(parsedObject.contracttype[0].index != ""){
          printdata +='<tr>';

          printdata +='<td>Index name</td>';
          printdata +='<td>'+parsedObject.contracttype[0].index+'</td>';
          printdata +='</tr>';
        }
        printdata +='</table>';
        $('.preview1').html(printdata);
        var printtwodata = '';
        printtwodata +='<div class="row">';
        printtwodata +='<div class="col-md-6">';
        printtwodata +='<h6>Length Consumption</h6>';
        printtwodata +='</div>'
        printtwodata +='<div class="col-md-6 text-right">'
        printtwodata +='<a class="btn btn-primary" onclick="showTabs(1,2)">Edit</a>';
        printtwodata +='</div>';
        printtwodata +='</div>';
        printtwodata +='<table class="table">';
        printtwodata +='<tr>';
        printtwodata +='<td>Contract Term</td>';
        printtwodata +='<td>'+parsedObject.contractterm+'</td>';
        printtwodata +='</tr>';
        printtwodata +='<tr>';
        printtwodata +='<td>Commodity Price</td>';
        printtwodata +='<td>'+parsedObject.comodityprice+'</td>';
        printtwodata +='</tr>';
        printtwodata +='<tr>';
        printtwodata +='<td>Contract Price Type</td>';
        printtwodata +='<td>'+parsedObject.contractprice+'</td>';
        printtwodata +='</tr>';
        printtwodata +='<tr>';
        printtwodata +='<td>Total Anual Consumption</td>';
        printtwodata +='<td>'+parsedObject.totalanualconsumption+'</td>';
        printtwodata +='</tr>';
        printtwodata +='<tr>';

        var allmonths = $('.allmonths').val();
            allmonths = allmonths.split(',');
           
        var getmnts = [];
        for(var j=0;j<allmonths.length;j++){
            var splitmonth = allmonths[j].split('-');
            getmnts.push(splitmonth[1]);
        }
        var totalmonths = getmnts.length;
        if(totalmonths>12){
          totalmonths = 12;
        }
        for(var i=0;i<totalmonths;i++){
          var monthja = $('.months'+i).val();
          printtwodata +='<td>'+$('.months'+i).val()+ ' Consumption</td>';
          var cons =eval('parsedObject.'+monthja+'consumption');
          printtwodata +='<td>'+cons+'</td>';
          printtwodata +='</tr>';
          printtwodata +='<tr>';
        }
       

        printtwodata +='</table>';
        $('.preview2').html(printtwodata);
         
        }



      }
    
      
    if(currentTab == 2){
      var retrievedObject = localStorage.getItem('obj');
      var parsedObject = JSON.parse(retrievedObject);
      console.log(parsedObject);
      parsedObject.index = $('.indexstr:checked').val();
      parsedObject.totalanualconsumption = $('.totalanualconsumption').val();
      var rowcount = $('.rowcount').val();
      var tradper = [];
      var tranches = [];
      var consumption =[];

      for ( i = 0; i < rowcount; i++) {
        if(typeof($('.tradsel'+i).val()) != "undefined"){
          tradper.push($('.tradsel'+i).val());
          var value = $('.tradsel'+i).val();
          var vals = value;
          tranches.push($('.tradsel'+i).val()+'-'+$('.tranche'+i).val());
          consumption.push($('.minsize'+i).val()+'-'+$('.minsizevalue'+i).val());
        }
      }
      var allper =  tradper.toString();
      parsedObject[vals]= tranches.toString();
      parsedObject.allowperiod = allper;
      var mins = $('.clnmin').val();
      parsedObject[mins] = $('.minsize').val();
      parsedObject.pricMech = $('.pricMech').val();
      var x = document.getElementsByClassName("tab");
     
      var printdata = '';
        printdata +='<div class="row">';
        printdata +='<div class="col-md-6">';
        printdata +='<h6>Contract Details</h6>';
        printdata +='</div>'
        printdata +='<div class="col-md-6 text-right">'
        printdata +='<a class="btn btn-primary" onclick="showTabs(0,3)">Edit</a>';
        printdata +='</div>';
        printdata +='</div>';
        printdata +='<table class="table">';
        printdata +='<tr>';
        printdata +='<td>Client</td>';
        printdata +='<td>'+parsedObject.client+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Country</td>';
        printdata +='<td>'+parsedObject.country+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Commodity</td>';
        printdata +='<td>'+parsedObject.commodity[0].name+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Supplier</td>';
        printdata +='<td>'+parsedObject.supplier+'</td>';
        printdata +='</tr>';
        printdata +='<tr>';
        printdata +='<td>Contract Type</td>';
        printdata +='<td>'+parsedObject.contracttype[0].type+'</td>';
        printdata +='</tr>';
        if(parsedObject.contracttype[0].index != ""){
          printdata +='<tr>';

          printdata +='<td>Index name</td>';
          printdata +='<td>'+parsedObject.contracttype[0].index+'</td>';
          printdata +='</tr>';
        }
        printdata +='</table>';
        $('.preview1').html(printdata);
        var printtwodata = '';
        printtwodata +='<div class="row">';
        printtwodata +='<div class="col-md-6">';
        printtwodata +='<h6>Length Consumption</h6>';
        printtwodata +='</div>'
        printtwodata +='<div class="col-md-6 text-right">'
        printtwodata +='<a class="btn btn-primary" onclick="showTabs(1,3)">Edit</a>';
        printtwodata +='</div>';
        printtwodata +='</div>';
        printtwodata +='<table class="table">';
        printtwodata +='<tr>';
        printtwodata +='<td>Contract Term</td>';
        printtwodata +='<td>'+parsedObject.contractterm+'</td>';
        printtwodata +='</tr>';
        
        printtwodata +='<tr>';
        printtwodata +='<td>Contract Price Type</td>';
        printtwodata +='<td>'+parsedObject.contractprice+'</td>';
        printtwodata +='</tr>';

          // printtwodata +='<tr>';
          // printtwodata +='<td>Commodity Price</td>';
          // printtwodata +='<td>'+parsedObject.comodityprice+'</td>';
          // printtwodata +='</tr>';

        printtwodata +='<tr>';
        printtwodata +='<td>Total Anual Consumption</td>';
        printtwodata +='<td>'+parsedObject.totalanualconsumption+'</td>';
        printtwodata +='</tr>';
        printtwodata +='<tr>';

        var allmonths = $('.allmonths').val();
            allmonths = allmonths.split(',');
           
        var getmnts = [];
        for(var j=0;j<allmonths.length;j++){
            var splitmonth = allmonths[j].split('-');
            getmnts.push(splitmonth[1]);
        }
        var totalmonths = getmnts.length;
        if(totalmonths>12){
          totalmonths = 12;
        }
        for(var i=0;i<totalmonths;i++){
          var monthja = $('.months'+i).val();
          printtwodata +='<td>'+$('.months'+i).val()+ ' Consumption</td>';
          var cons =eval('parsedObject.'+monthja+'consumption');
          printtwodata +='<td>'+cons+'</td>';
          printtwodata +='</tr>';
          printtwodata +='<tr>';
        }

        printtwodata +='</table>';
        $('.preview2').html(printtwodata);
        var printthreedata = '';
        printthreedata +='<div class="row">';
        printthreedata +='<div class="col-md-6">';
        printthreedata +='<h6>Index Details</h6>';
        printthreedata +='</div>'
        printthreedata +='<div class="col-md-6 text-right">'
        printthreedata +='<a class="btn btn-primary" onclick="showTabs(2,3)">Edit</a>';
        printthreedata +='</div>';
        printthreedata +='</div>';
        printthreedata +='<table class="table">';
        printthreedata +='<tr>';
        printthreedata +='<td>Index Structure</td>';
        printthreedata +='<td>'+parsedObject.index+'</td>';
        printthreedata +='</tr>';

        printthreedata +='<tr>';
        printthreedata +='<td>Allowable Trade Periods</td>';
        printthreedata +='<td>'+parsedObject.allowperiod+'</td>';
        printthreedata +='</tr>';
        var tradeper = parsedObject.allowperiod;
        var arrayval = tradeper.split(",");
        parsedObject.cons = consumption.toString();
        

        console.log(arrayval);
        var consum = ['% consumption','#MWhs'];
        for(var key in parsedObject){
          if(arrayval.includes(key)){
            printthreedata +='<tr>';
            printthreedata +='<td>'+key+' clicks / Tranches</td>';
            printthreedata +='<td>'+parsedObject[key]+'</td>';
            printthreedata +='</tr>';
          }
          // if(consum.includes(key)){
          //   printthreedata +='<tr>';
          //   printthreedata +='<td>clicks / Tranches Minimum size ('+key+')</td>';
          //   printthreedata +='<td>'+parsedObject[key]+'</td>';
          //   printthreedata +='</tr>';
          // }
        
        }
        printthreedata +='<tr>';
        printthreedata +='<td>clicks / Tranches Minimum size </td>';
        printthreedata +='<td>'+parsedObject.cons+'</td>';
        printthreedata +='</tr>';
        printthreedata +='<tr>';

        printthreedata +='<td>Open Position Pricing Mechanism</td>';
        printthreedata +='<td>'+parsedObject.pricMech+'</td>';
        printthreedata +='</tr>';
        
        printthreedata +='</table>';
        $('.preview3').html(printthreedata);

        
    }



  }

  
    if (n == 1 && !validateForm()) return false;
    x[currentTab].style.display = "none";
    currentTab = currentTab + n;
    if (currentTab >= x.length) {

        var form = document.getElementById("regForm");
        form.submit();
        return false;

    }
    showTab(currentTab);
}
 
function validateForm() {


  
  return true; 
}

  $(".commodity").each(function () {
    
    $(this).on('change',function(){
      if($(this).prop('checked', true)){
          
        if($(this).val() == 'natural gas'){
          $('.units').css('display','block');
        }else{
          $('.units').css('display','none');
        }
      }
    })
    
    
    
  });
$('.contactType').on('change',function(){
  if($(this).prop('checked', true)){
    if($(this).val() == 'indexed'){
      $('.indexcl').css('display','block');
    }else{
      $('.indexcl').css('display','none');
    }
  }
});

$('input[type="checkbox"].indexstr').on('change', function() {
   $('input[type="checkbox"].indexstr').not(this).prop('checked', false);
});
$('input[type="checkbox"].commodity').on('change', function() {
   $('input[type="checkbox"].commodity').not(this).prop('checked', false);
});
$('input[type="checkbox"].unit').on('change', function() {
   $('input[type="checkbox"].unit').not(this).prop('checked', false);
});
$('input[type="checkbox"].contactType').on('change', function() {
   $('input[type="checkbox"].contactType').not(this).prop('checked', false);
});

function getclientdetails(clientId){
  $.ajax({
      type:'POST',
      url: 'js/callbacks/getclientdeails.php',
      data:{
        'clientId':clientId
      
      },
      success: function(data){
        var obj = JSON.parse(data);
        $('.country').val(obj.clientcountry);
        $('.clientname').val(obj.clientname);
        console.log(data);
      }
    });
}

function calcualteMonthYr(startdate,enddate){
    var todate = new Date();
    if(enddate){
        todate = new Date(enddate);
    }
    var fromdate = new Date();
    if(startdate){
        fromdate = new Date(startdate);
    }

    var getstartmonth = fromdate.getMonth();
    var getendmonth = todate.getMonth();
    var months=0;
        months = (todate.getFullYear() - fromdate.getFullYear()) * 12;
        months -= fromdate.getMonth();
        months += todate.getMonth();
            // if (todate.getDate() < fromdate.getDate()){
            //     months--;
            // }
   
    var dates      = [];
    var startYear =  fromdate.getFullYear();
    var endYear = todate.getFullYear();
    for(var i = startYear; i <= endYear; i++) {
      var endMonth = i != endYear ? 11 : parseInt(getendmonth) ;

      var startMon = i === startYear ? parseInt(getstartmonth) : 0;
      console.log('>>startmnt'+startMon+'>>endMonth'+endMonth);
      for(var j = startMon; j <= endMonth; j = j > 12 ? j % 12 || 11 : j+1) {
        var month = j+1;
        var displayMonth = month < 10 ? month : month;
        dates.push([i, displayMonth, '01'].join('-'));
      }
    }
    console.log(dates);
    $('.allmonths').val(dates);
    $('.countmonths').val(months+1);
  
}
function addTradeperiods(){
  var rowcount = parseInt($('.rowcount').val());
  var printData = '';
      printData +='<div class="trade'+rowcount+'">';
      printData +='<div class="row">';
      printData +='<div class="col-md-7">';
      printData +='</div>';
      printData +='<div class="col-md-5">';
      printData +='<label>Clicks/tranches</label><br>';            
      printData +='</div>';
      printData +='</div>';
      printData +='<div class="row">';
      printData +='<div class="col-md-6">';
      printData +='<select class="chosen-select tradsel'+rowcount+'" name="tradsel'+rowcount+'">';
      printData +='<option value="">Select option</option>';
      printData +='<option value="Calendar Yearly">Calendar Yearly</option>';
      printData +='<option value="Calendar Quarterly">Calendar Quarterly</option>';
      printData +='<option value="Calendar Monthly">Calendar Monthly</option>';
      printData +='</select>';
      printData +='</div>';
      printData +='<div class="col-md-4">';
      printData +='<input type="text" class="form-control tranche'+rowcount+'" name="tranche'+rowcount+'">';
      printData +='</div>';
      printData +='<div class="col-md-2"><i class="fa fa-trash-o" onclick="removerow('+rowcount+')" aria-hidden="true"></i>';
      printData +='</div>';
      printData +='</div>';
      printData +='<div class="row">';
      printData +='<label>Clicks/tranche minimum size</label><br>';
      printData +='<div class="input-group">';
      printData +='<span class="input-group-addon transparent" style="width: 30%;">';
      printData +='<select class="clnmin minsize'+rowcount+'" name="minsize'+rowcount+'">';
      printData +='<option value="% consumption">% consumption</option>';
      printData +='<option value="#MWhs">#MWhs</option>';
      printData +='</select>';
      printData +='</span>';
      printData +='<input class="form-control left-border-none minsizevalue'+rowcount+'" name="minsizevalue'+rowcount+'" type="text">';
      printData +='<span class="input-group-addon transparent"> %</span>';
      printData +='</div>';
      printData +='</div>';
      printData +='</div>';
      printData +='<hr>';

  $('.addTrade').append(printData);
  $('.rowcount').val(rowcount+1);
  
}
function removerow(row){
  $('.trade'+row).remove();
}
</script>
    <?php
        include('hoverinclude/hoversupply.php');
    ?>

</body>
</html>