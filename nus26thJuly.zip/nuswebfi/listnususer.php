<?php

include ('dbconn.php');
    $sql = "select username, emailid, accountstatus from nususerdata where role=\"NUS user\";";
    $result = ($conn->query($sql));
	//declare array to store the data of database
	$row = [];

	if ($result->num_rows > 0)
	{
		// fetch all data from db into array
		$row = $result->fetch_all(MYSQLI_ASSOC);
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS Consulting Group | Client Company List</title>
    <link
      rel="stylesheet"
      href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css"
    />
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        
        table {
            border: 2px solid #CED4DA;
            border-radius: 6px;
        }
        table th {
        color: #343a40;
        background: #F9FBFD;
    }
    table.myTable thead th {
        border-bottom: 1px solid #CED4DA !important;
    }
    table td {
        color: #12263F;
        font-size: 13px;
        border-bottom: 1px solid #CED4DA;
    }
    table.dataTable.no-footer {
        /* border-bottom: 2px solid #D2DDEC !important; */
        border-bottom: none !important;
    }
    </style>
</head>
<body>

<table class="myTable">
<thead>
			<tr>	
            <th></th>	
            <th>Username</th>
            <th>Email</th>
            <th>Account Status</th>
        
			<th></th>

			</tr>
		</thead>
		<tbody>
			<?php
                if(!empty($row))
                foreach($row as $rows)
                {
                ?>
                <tr>       
                    <td><input type="checkbox"></td>
                    <td><?php echo $rows['username']; ?></td>
                    <td><?php echo $rows['emailid']; ?></td>
                    <?php
                    if($rows['accountstatus'] == 'Confirmed') {
                ?>
				<td><span style="background: #DCFFF0; color: #026A3E; padding: 5px 15px; border-radius: 3px; font-weight: 500;"><?php echo $rows['accountstatus'];?></span></td>
                <?php
                    } else { ?>
                    				<td><span style="background: #FFF4BD; color: #665600; padding: 5px 15px; border-radius: 3px; font-weight: 500;"><?php echo $rows['accountstatus'];?></span></td>
                    <?php
                    }?>
                              
				<td class="threedot">
				<div class="btn-group">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                     <i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                    <ul class="dropdown-menu" role="menu">

<li>
                                <a id="editing" href="edituser.php">Edit Details</a>
                            </li>
                            <li>
                                <a href="move.php" id="moving">Move User</a>
                            </li>
                            <li>
                                <a href="disable.php" id="moving">Disable User</a>
                            </li>
                           
                    </ul>
                  </div>
				</td>

                </tr>
			<?php } ?>
		</tbody>
    </table>
</body>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
        $(".myTable").DataTable();
        });
    </script>
    <script>
    document.querySelector('table').onclick = ({
    target
    }) => {
    if (!target.classList.contains('click')) return
    document.querySelectorAll('.dropouts.active').forEach(
        (d) => d !== target.parentElement && d.classList.remove('active')
    )
    target.parentElement.classList.toggle('active')
    }
</script>
</html>